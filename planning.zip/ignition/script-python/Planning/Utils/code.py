def list_of_sites(database):
	"""Créer et renvoi la liste des sites de la base de données"""
	sites = system.db.runQuery('Select distinct(site) from equipements', database)
	return [elt[0] for elt in sites]

def create_dict_sites(database):
	"""
	Créer et renvoi un dictionnaire contenant en clé et valeur le nom du site.
	La valeur peut être associé au nom devio du site ou au nom du device (modbus)
	"""
	sites = list_of_sites(database)
	return {site: site for site in sites}


def list_second_elt(liste):
	"""
	Renvoi
		- le premier élément de la liste sielle est de taille 1
		- le second élément dans les autres cas
	"""
	if len(liste) > 1 :
		return liste[-1]
	else:
		return liste[0]
