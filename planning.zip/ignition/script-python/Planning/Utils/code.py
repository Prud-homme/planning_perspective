def create_dict_sites():
	"""
	Créer et renvoi un dictionnaire contenant en clé le nom du site et en valeur le nom devio du site
	"""
	sites = system.db.runQuery('Select distinct(site) from equipements', database)
	sites_dict = {}
	for elt in sites:
		site = str(elt[0])
		sites_dict[site] = site
	return sites_dict