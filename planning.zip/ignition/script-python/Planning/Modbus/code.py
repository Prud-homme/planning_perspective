import system

def liste_info_site_modbus(database, site):
    """Renvoi une liste contenant chaque equipement du site avec son groupe et num_mb"""
    query = """
    select groupe, equipement, num_mb from equipements
    where site = '%s'
    and num_mb is not null
    """ % (
        site
    )
    data = []
    for groupe, equipement, num_mb in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), num_mb])
    return data


def horaires_site_modbus(database, site, device, serverOPCUA):
    """Decoupe en fonction d'un site"""
    data = liste_info_site_modbus(database, site)
    for groupe, equipement, num_mb in data:
        depart = 25001 + (num_mb - 1) * 113
        adresses_gp_eq = range(depart, depart+113)
        adresses_gp_eq = ["[" + device + "]255.HR" + str(elt) for elt in adresses_gp_eq]
        
        values_gp_eq = Planning.GetPlanning.horaires_gp_eq(database, site, groupe, equipement)
        values_gp_eq.insert(0,0)
        
        returnQuality = system.opc.writeValues(serverOPCUA, adresses_gp_eq, values_gp_eq)
        system.tag.writeBlocking(["[default]Plannings/" + site + "/DevIO"],[str(returnQuality)])
        #print returnQuality

def horaires_modbus(database, serverOPCUA, devices):
    """Parcours de tous les sites"""
    for site, device in devices.items():
    	# Ajout du Tag si n'existe pas
		if not system.tag.exists("[default]Plannings/" + site + "/Modbus"):
			baseTagPath = "[default]Plannings/" + site
		
			tag = {
					  "valueSource": "memory",
					  "dataType": "String",
					  "name": "Modbus",
					  "value": "",
					  "tagType": "AtomicTag"
					}
						
			collisionPolicy = "a"
			system.tag.configure(baseTagPath, [tag], collisionPolicy)
		
		try:
        	horaires_site_modbus(database, site, device, serverOPCUA)
        except:
        	system.tag.writeBlocking(["[default]Plannings/" + site + "/Modbus"],["Erreur du script pour " + site])

"""
# Script à mettre dans la gateway
# Nom database Ignition
database = "MYSQL"

# Nom du serveur OPC UA
server = "Ignition OPC UA Server"

#Association Device et Site (Nom identique)
devices = Planning.Utils.create_dict_sites()
#Association Device et Site (Nom différent)
devices["Site1"] = "Device1"
devices["Site1"] = "Device1"

# Lancement du script
Planning.Modbus.horaires(database, serverOPCUA, devices)
# --- Fin script ---
"""
