def liste_info_site_devio(database, site):
    """
    Renvoi une liste contenant chaque equipement du site avec
    son groupe et son id_devio
     """
    query = """
    select groupe, equipement, id_devio from equipements
    where site = '%s'
    and id_devio is not null
    """ % (
        unicode(site)
    )
    data = []
    for groupe, equipement, id_devio, nom_devio in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), id_devio, nom_devio])
    return data


def horaires_site_devio(database, site, equipment_devio):
	"""
	Récupération des plannings de chaque équipement d'un site et création d'un fichier XML
	contenant ces plannings
	"""
	data = liste_info_site_devio(database, site)
	newdoc, noderoot, nodeplannings = Planning.XML.create_document(equipment_devio)
	#print newdoc.toprettyxml(), noderoot.toprettyxml(), nodeplannings.toprettyxml(), data
	for groupe, equipement, id_devio in data:
		values_gp_eq = Planning.GetPlanning.horaires_gp_eq(database, site, groupe, equipement)
		nodeplanning = Planning.XML.create_node_periode(newdoc, plannings_values, id_devio)
		#print nodeplanning.toprettyxml()
		nodeplannings.appendChild(nodeplanning)
	noderoot.appendChild(nodeplannings)
	
	retVal = noderoot.toprettyxml()
	newdoc.unlink()
	retVal.replace(" 	","   ")
	retVal.replace("	","   ")
	#print retVal
	system.tag.writeBlocking(["[default]Plannings/" + site + "/DevIO"],[retVal])
		
		
def copy_devio_tag_to_writeplanningrequest_tag(database):
	"""Copie le tag contenant le planning au format XML dans le tag qui envoi les plannings"""
	sites = Planning.Utils.list_of_sites(database)
	for site in sites:
		if system.tag.exists("[default]Plannings/%s/DevIO"%(site)):
			path = ["[default]%s/Planning/_WritePlanningRequest"%(site)]
			value = [system.tag.readBlocking(["[default]Plannings/%s/DevIO"%(site)])[0].value]
			system.tag.writeBlocking(path, value)
				

"""
# Script à mettre dans la gateway
# Nom database Ignition (a changer si besoin)
database = "MYSQL"

#Association Equipment DevIO et Site (Nom identique)
equipments_devio = Planning.Utils.create_dict_sites(database)
#Association Device et Site (Nom différent)
# equipments_devio["Nom SQL"] = "Nom DevIO"

# Lancement du script
Planning.DevIO.create_xml(database, equipments_devio)
# --- Fin script ---
"""
