import system

def liste_info_site_devio(database, site):
    """Renvoi une liste contenant chaque equipement du site avec son groupe, son id_devio et son nom_devio"""
    query = """
    select groupe, equipement, id_devio, nom_devio from equipements
    where site = '%s'
    and id_devio is not null
    and nom_devio is not null
    """ % (
        site
    )
    data = []
    for groupe, equipement, id_devio, nom_devio in system.db.runQuery(query, database):
        data.append([str(groupe), str(equipement), id_devio, nom_devio])
    return data


def horaires_site_devio(database, site, equipment_devio):
	"""Decoupe en fonction d'un site"""
	data = liste_info_site_devio(database, site)
	newdoc, noderoot, nodeplannings = Planning.XML.create_document(equipment_devio, type=None)
	#print newdoc.toprettyxml(), noderoot.toprettyxml(), nodeplannings.toprettyxml()
	for groupe, equipement, id_devio, nom_devio in data:
		
		values_gp_eq = Planning.GetPlanning.horaires_gp_eq(database, site, groupe, equipement)
		nodeplanning = Planning.XML.create_node_planning(newdoc, values_gp_eq, id_devio, nom_devio)
		#print nodeplanning.toprettyxml()
		nodeplannings.appendChild(nodeplanning)
	noderoot.appendChild(nodeplannings)
	
	retVal = noderoot.toprettyxml()
	newdoc.unlink()
	retVal.replace(" 	","   ")
	retVal.replace("	","   ")
	print retVal
	system.tag.writeBlocking(["[default]Plannings/" + site + "/DevIO"],[retVal])
		

def horaires_devio(database, equipments_devio):
	"""Parcours de tous les sites"""
	for site, equipment_devio in equipments_devio:
		# Ajout du Tag si n'existe pas
		if not system.tag.exists("[default]Plannings/" + site + "/DevIO"):
			baseTagPath = "[default]Plannings/" + site
		
			tag = {
					  "valueSource": "memory",
					  "dataType": "String",
					  "name": "DevIO",
					  "value": "",
					  "tagType": "AtomicTag"
					}
						
			collisionPolicy = "a"
			system.tag.configure(baseTagPath, [tag], collisionPolicy)

		try:
			horaires_site_devio(database, site, equipment_devio)
		except:
			system.tag.writeBlocking(["[default]Plannings/" + site + "/DevIO"],["Erreur du script pour " + site])


"""
# Script à mettre dans la gateway
# Nom database Ignition
database = "MYSQL"

#Association Equipment DevIO et Site (Nom identique)
equipments_devio = Planning.Utils.create_dict_sites()
#Association Device et Site (Nom différent)
equipments_devio["Site1"] = "Equipment1"
equipments_devio["Site1"] = "Equipment2"

# Lancement du script
Planning.DevIO.horaires_devio(database, equipments_devio)
# --- Fin script ---
"""