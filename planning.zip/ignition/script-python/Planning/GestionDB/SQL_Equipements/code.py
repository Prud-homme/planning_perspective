def create_tables(database):
	"""Creation des tables nécessaire au module Planning"""
	queries = [
		"""
		CREATE TABLE equipements
		(
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT
		)
		""",	
		"""
		CREATE TABLE plannings
		(
		  h_start TEXT,
		  m_start TEXT,
		  h_stop TEXT,
		  m_stop TEXT,
		  plage INT,
		  jour INT,
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT
		)
		""",
		"""
		CREATE TABLE plannings_exception
		(
		  h_start TEXT,
		  m_start TEXT,
		  h_stop TEXT,
		  m_stop TEXT,
		  date_deb TEXT,
		  date_fin TEXT,
		  plage INT,
		  site TEXT,
		  groupe TEXT,
		  equipement TEXT,
		  commentaire TEXT
		)
		""",
	]
	results = [system.db.runUpdateQuery(query, database) for query in queries]

	
def add_support_for_modbus(database):
	"""Ajout du champs Modbus pour l'écriture des plannings en modbus"""
	queries = ["ALTER TABLE equipements ADD COLUMN num_mb INT"]
	results = [system.db.runUpdateQuery(query, database) for query in queries]
	
	
def add_support_for_devio(database):
	"""Ajout du champs DevIO pour la création des plannings au format XML"""
	queries = ["ALTER TABLE equipements ADD COLUMN id_devio INT"]
	results = [system.db.runUpdateQuery(query, database) for query in queries]
	

def query_select_equipements(site, groupe, equipement):
	"""Verifier la présence de l'equipement dans la table equipements"""
	query = """
	Select * from equipements
	where site= '%s' 
	and groupe='%s' 
	and equipement = '%s'
	""" % (
		unicode(site),
		unicode(groupe),
		unicode(equipement),
	)
	return query
	
	
def query_insert_equipements(site, groupe, equipement):
	"""Ajout de l'equipement dans la table equipements"""
	query = """
	Insert into equipements (site, groupe, equipement)
	Values ('%s', '%s', '%s')
	""" % (
		unicode(site),
		unicode(groupe),
		unicode(equipement),
	)
	return query

	
def update_equipements(database, site, groupe, equipement):
	"""Ajout de l'equipement a la bdd s'il n'est pas deja present"""
	query = query_select_equipements(site, groupe, equipement)		
	result = system.db.runQuery(query,database)
	if len(result)==0:
		query = query_insert_equipements(site, groupe, equipement)
		system.db.runUpdateQuery(query,database)
		

def query_select_plannings(site, groupe, equipement, plage, jour):
	"""Verifier la presence de l'equipement pour ce jour et cette plage dans la table plannings"""
	query = """
	Select * from plannings
	where plage=%d
	and jour=%d
	and site= '%s'
	and groupe='%s'
	and equipement = '%s' 
	""" % ( 
		plage, 
		jour, 
		unicode(site), 
		unicode(groupe), 
		unicode(equipement),
	)
	return query
	
			
def query_insert_plannings(site, groupe, equipement, plage, jour):
	"""Ajout du jour et plage pour l'equipement dans la table plannings"""
	query = """
	Insert into plannings
	(h_start, m_start, h_stop, m_stop, plage, jour, site, groupe, equipement)
	Values ('%s','%s','%s','%s', %d, %d,'%s','%s','%s')
	""" % (
		"00",
		"00",
		"00",
		"00",
		plage,
		jour,
		unicode(site),
		unicode(groupe),
		unicode(equipement),
	)
	return query


def update_plannings(database, site, groupe, equipement):
	"""Pre-remplissage de la table plannings pour la période hebdo, verifie la presence avant ajout"""
	list_jours = [1,2,3,4,5,6,7]
	list_plages = [1,2,3,4]	
	for jour in list_jours:
		for plage in list_plages:
			query = query_select_plannings(site, groupe, equipement, plage, jour)
			result = system.db.runQuery(query,database)
			if len(result)==0:
				query = query_insert_plannings(site, groupe, equipement, plage, jour)
				system.db.runUpdateQuery(query,database)
	

def add_num_mb(database, site, groupe, equipement, num_mb):
	"""Ajout du numero modbus de l'equipement dans la table equipements"""
	if num_mb is None or not str(num_mb).isdecimal():
		return None
	query = """UPDATE equipements 
	SET 
		num_mb = %d
	WHERE site='%s'
	AND groupe='%s'
	AND equipement='%s'
	""" % (
		int(num_mb),
		unicode(site),
		unicode(groupe),
		unicode(equipement),
	)
	system.db.runUpdateQuery(query,database)
	

def add_devio(database, site, groupe, equipement, id_devio):
	"""Ajout de l'id DevIO de l'equipement dans la table equipements"""
	if id_devio is None or not str(id_devio).isdecimal():
		return None
	query = """UPDATE equipements 
	SET 
		id_devio=%d
	WHERE site='%s'
	AND groupe='%s'
	AND equipement='%s'
	""" % (
		int(id_devio),
		unicode(site),
		unicode(groupe),
		unicode(equipement),
	)
	system.db.runUpdateQuery(query,database)
	

def update_tables(database, dataset, avec_modbus, avec_devio):
	"""Met a jour les tables equipements et plannings en fonction des donnees fournies"""
	for i in range(dataset.getRowCount()):
		site = dataset.getValueAt(i, "site")
		groupe = dataset.getValueAt(i, "groupe")
		equipement = dataset.getValueAt(i, "equipement")
		
		update_equipements(database, site, groupe, equipement)
		update_plannings(database, site, groupe, equipement)
		
		if avec_modbus:
			num_mb = dataset.getValueAt(i, "num_mb")
			if num_mb is not None: 
				add_num_mb(database, site, groupe, equipement, num_mb)
			
		if avec_devio:
			id_devio = dataset.getValueAt(i, "id_devio")
			if id_devio is not None:
				add_devio(database, site, groupe, equipement, id_devio)
