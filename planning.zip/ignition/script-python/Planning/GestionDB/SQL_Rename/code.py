def rename_site(database, old_site, new_site):
	"""Renomme le site par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		unicode(new_site),
		unicode(old_site),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		unicode(new_site),
		unicode(old_site),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		site='%s'
	WHERE site='%s'
	""" % (
		unicode(new_site),
		unicode(old_site),
	)
	system.db.runUpdateQuery(query,database)
	

def rename_gp(database, site, old_groupe, new_groupe):
	"""Renomme le groupe d'un site par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		unicode(new_groupe),
		unicode(site),
		unicode(old_groupe),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		unicode(new_groupe),
		unicode(site),
		unicode(old_groupe),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		groupe='%s'
	WHERE site='%s'
	and groupe='%s'
	""" % (
		unicode(new_groupe),
		unicode(site),
		unicode(old_groupe),
	)
	system.db.runUpdateQuery(query,database)


def rename_equip(database, site, groupe, old_equip, new_equip):
	"""Renomme l'equipement d'un site et groupe par un nouveau nom (plannings, plannings_exception, equipements)"""
	query = """UPDATE equipements 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		unicode(new_equip),
		unicode(site),
		unicode(groupe),
		unicode(old_equip),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		unicode(new_equip),
		unicode(site),
		unicode(groupe),
		unicode(old_equip),
	)
	system.db.runUpdateQuery(query,database)
	
	query = """UPDATE plannings_exception 
	SET 
		equipement='%s'
	WHERE site='%s'
	and groupe='%s'
	and equipement='%s'
	""" % (
		unicode(new_equip),
		unicode(site),
		unicode(groupe),
		unicode(old_equip),
	)
	system.db.runUpdateQuery(query,database)
	

def rename(database, dataset1, dataset2, field):
	"""Met a jour les tables equipements et plannings en fonction des donnees fournies"""
	for i in range(dataset1.getRowCount()):
		old_value = dataset1.getValueAt(i, field)
		new_value = dataset2.getValueAt(i, 0)
		if old_value == new_value:
			continue
		
		if field == "site":
			rename_site(database, old_value, new_value)
		
		elif field == "groupe":
			site = dataset1.getValueAt(i, "site")
			rename_gp(database, site, old_value, new_value)
			
		elif field == "equipement":
			site = dataset1.getValueAt(i, "site")
			groupe = dataset1.getValueAt(i, "groupe")
			rename_equip(database, site, groupe, old_value, new_value)
		

def table_field_rename(database, table_name, field):
	"""
	Recupère les données à éditer renvoi un dataset contenant l'ensemble des informations
	et un dataset contenant le contenu éditable
	"""
	if not Planning.GestionDB.SQL.table_exist(database, table_name) or field not in ["site", "groupe", "equipement"]:
		return None
			
	search = {
		"site": "select distinct site from equipements",
		"groupe": "select distinct site, groupe from equipements",
		"equipement": "select distinct site, groupe, equipement from equipements",
	}
	
	results = system.db.runQuery(search[field], database)
	
	headers = list(results.getColumnNames())
	headers_extract = [field]
	if len(results) > 0:
		data = [list(row) for row in results]
		data_extract = [[elt[-1]] for elt in data]
	else:
		data = []
		data_extract = []
		
	dataset = system.dataset.toDataSet(headers,data)
	dataset_extract = system.dataset.toDataSet(headers_extract,data_extract)
	return dataset, dataset_extract
