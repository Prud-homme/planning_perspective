def table_exist(database, table_name):
	"""Vérifie si la table existe dans la base de données"""
	try:
		query = """select exists(
	SELECT * FROM information_schema.tables
	WHERE table_name = '%s')""" % (table_name)
		results = system.db.runQuery(query, database)
		return len(results) > 0
	except:
		return False
	

def get_dataset(database, table_name):
	"""Renvoi un dataset contenant les données d'une table si la table existe dans la BDD"""
	if not table_exist(database, table_name):
		return None

	query = "SELECT * FROM %s" % (table_name)
	results = system.db.runQuery(query, database)

	headers = list(results.getColumnNames())
	if len(results) > 0:
		data = [list(row) for row in results]
	else:
		data = []
	return system.dataset.toDataSet(headers, data)
