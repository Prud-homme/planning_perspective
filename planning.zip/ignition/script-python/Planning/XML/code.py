from xml.dom import minidom
		
def setAttributeFiltered(node,attribute,value):
	if value!='' and value!=None:
		node.setAttribute(attribute,str(value))
		

def extract_plage_of_day(planning_values, n_day, n_plage):
	"""
	Extrait l'heure de début, la minute de début, l'heure de fin et la minute de fin pour une plage et un jour donné
	planning_values: liste des 112 valeurs du planning pour un équipement (list[int])
	n_day: numéro du jour entre 0 et 6 (int)
	n_plage: numéro de la plage entre 0 et 3 (int)
	"""
	start_index = n_day * 16 + n_plage * 4
	#print "extract(%d, %d) --- "%(n_day, n_plage), planning_values[start_index:start_index+4]
	return planning_values[start_index:start_index+4]


def create_node_plage(newdoc, plage_values, n_plage):
	"""
	IOControl="3"
	Créer et renvoi un noeud XML d'une période de temps d'une plage et jour donné
	plage_values: heure de début, minute de début, heure de fin et minute de fin (plage et jour donné) (list[int])
	n_plage: numéro de la plage entre 0 et 3 (int)
	"""
	nodeplage = newdoc.createElement("Plage")
	nodeplage.setAttribute("n",str(n_plage+1))
	
	h_deb = ':'.join((str(plage_values[0]), str(plage_values[0])))
	h_fin = ':'.join((str(plage_values[2]), str(plage_values[3])))
	
	setAttributeFiltered(nodeplage,"debut", h_deb)
	setAttributeFiltered(nodeplage,"fin", h_fin)
	
	return nodeplage


def create_node_jour(newdoc, plannings_values, n_day):
	"""
	IOControl="3"
	Créer et renvoi un noeud XML d'un jour donnée
	plannings_values: liste des 112 valeurs du planning pour un équipement (list[int])
	n_day: numéro du jour entre 0 et 6 (int)
	"""
	Jour=["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"]					
	nodejour = newdoc.createElement("Jour")
	nodejour.setAttribute("nom", Jour[n_day])
	
	for n_plage in range(4):
		plage_values = extract_plage_of_day(plannings_values, n_day, n_plage)
		nodeplage = create_node_plage(newdoc, plage_values, n_plage)
		nodejour.appendChild(nodeplage)
	
	return nodejour
	
	
def create_node_periode(newdoc, plannings_values, id_devio):
	"""
	IOControl="3"
	Créer et renvoi un noeud XML contenant une periode hebdomadaire
	plannings_values: liste des 112 valeurs du planning pour un équipement (list[int])
	"""
	nodeperiode = newdoc.createElement("PeriodeHebdomadaire")
	nodeperiode.setAttribute("n",str(id_devio))
	
	for n_day in range(7):
		nodejour = create_node_jour(newdoc, plannings_values, n_day)
		nodeperiode.appendChild(nodejour)
	return nodedays
	
	
def create_document(equipment_devio):
	"""
	IOControl="3"
	Creer et renvoi un document XML pour un site devio
	"""
	newdoc = minidom.Document()
	
	noderoot = newdoc.createElement("DevIOFileOrder")
	newdoc.appendChild(noderoot)
	#print newdoc, type(newdoc)
	nodefile = newdoc.createElement("File")
	nodefile.setAttribute("Name", "Planning")
	nodefile.setAttribute("Equipment", unicode(equipment_devio))
	nodefile.setAttribute("IOControl", "3")
	nodefile.setAttribute("Status", "0")
	nodefile.setAttribute("Version", "2")
	noderoot.appendChild(nodefile)
	
	nodeplannings = newdoc.createElement("Plannings")
	
	return newdoc, noderoot, nodeplannings
