from xml.dom import minidom
import system
		
def setAttributeFiltered(node,attribute,value):
	if value!='' and value!=None:
		node.setAttribute(attribute,str(value))
		

def extract_plage_of_day(planning_values, n_day, n_plage):
	"""
	Extrait l'heure de début, la minute de début, l'heure de fin et la minute de fin pour une plage et un jour donné
	planning_values: liste des 112 valeurs du planning pour un équipement (list[int])
	n_day: numéro du jour entre 0 et 6 (int)
	n_plage: numéro de la plage entre 0 et 3 (int)
	"""
	start_index = n_day * 16 + n_plage * 4
	return planning_values[start_index:start_index+4]


def create_node_timeperiod(newdoc, plage_values, n_plage):
	"""
	Créer et renvoi un noeud XML d'une période de temps d'une plage et jour donné
	plage_values: heure de début, minute de début, heure de fin et minute de fin (plage et jour donné) (list[int])
	n_plage: numéro de la plage entre 0 et 3 (int)
	"""
	nodetimeperiod = newdoc.createElement("TimePeriod")	
	nodetimeperiod.setAttribute("IDTimePeriod", str(n_plage+1))
	nodetimeperiod.setAttribute("Name",str(n_plage+1))
	
	setAttributeFiltered(nodetimeperiod,"StartHour", str(plage_values[0]))
	setAttributeFiltered(nodetimeperiod,"StartMinute", str(plage_values[1]))
	setAttributeFiltered(nodetimeperiod,"StopHour", str(plage_values[2]))
	setAttributeFiltered(nodetimeperiod,"StopMinute", str(plage_values[3]))
	
	return nodetimeperiod
	
	
def create_node_day(newdoc, plannings_values, n_day):
	"""
	Créer et renvoi un noeud XML d'un jour donnée
	plannings_values: liste des 112 valeurs du planning pour un équipement (list[int])
	n_day: numéro du jour entre 0 et 6 (int)
	"""
	Jour=["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"]					
	nodeday = newdoc.createElement("Day")
	nodeday.setAttribute("IDDay", Jour[n_day])
	
	for n_plage in range(4):
		plage_values = extract_plage_of_day(plannings_values, n_day, n_plage)
		nodetimeperiod = create_node_timeperiod(newdoc, plage_values, n_plage)
		nodeday.appendChild(nodetimeperiod)
	
	return nodeday
	

def create_node_days(newdoc, plannings_values):
	"""
	Créer et renvoi un noeud XML contenant une periode hebdomadaire
	plannings_values: liste des 112 valeurs du planning pour un équipement (list[int])
	"""
	nodedays = newdoc.createElement("Days")
	for n_day in range(7):
		nodeday = create_node_day(newdoc, plannings_values, n_day)
		nodedays.appendChild(nodeday)
	return nodedays


def create_node_planning(newdoc, plannings_values, id_devio, nom_devio):
	"""
	Créer et renvoi le noeud XML d'un planning hebdomadaire d'un équipement
	plannings_values: liste des 112 valeurs du planning pour un équipement (list[int])
	id_devio: id devio de l'équipement (int)
	nom_devio: nom devio de l'équipement (str)
	"""
	print nom_devio, type(nom_devio), unicode(nom_devio)
	nodeplanning = newdoc.createElement("Planning")
	nodeplanning.setAttribute("IDPlanning", str(id_devio))
	nodeplanning.setAttribute("Name", nom_devio)
	nodedays = create_node_days(newdoc, plannings_values)
	nodeplanning.appendChild(nodedays)
	nodeexceptions = newdoc.createElement("Exceptions")
	nodeplanning.appendChild(nodeexceptions)
	return nodeplanning
	
	
def create_document(equipment_devio, type=None):
	"""
	Creer et renvoi un document XML pour un site devio
	"""
	newdoc = minidom.Document()
	
	noderoot = newdoc.createElement("DevIOFileOrder")
	newdoc.appendChild(noderoot)
	
	nodefile = newdoc.createElement("File")
	nodefile.setAttribute("Name","Planning")
	nodefile.setAttribute("Equipment",equipment_devio)
	nodefile.setAttribute("IOControl","2")
	nodefile.setAttribute("Status","0")
	nodefile.setAttribute("Version","2")
	noderoot.appendChild(nodefile)
	
	nodeplannings = newdoc.createElement("Plannings")
	setAttributeFiltered(nodeplannings, "Type", type)
	
	return newdoc, noderoot, nodeplannings
	

	