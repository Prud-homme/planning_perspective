def get_groupes(database, site):
	"""
	Génère et renvoi une liste de dictionnaire
	Chaque dictionnaire contient un champ label et un champs value qui représente un groupe
	Sera utilisé par des dropdown
	"""
	query = "SELECT DISTINCT groupe FROM equipements WHERE site='%s'" % (site)
	data = system.db.runQuery(query)
	
	if len(data) == 0 :
		return [{"value": "Aucun","label": "Aucun"}]
	else :
		list_options =[]
		for elt in data : 
			list_options.append({"value": elt[0],"label": elt[0]})
		return list_options


def get_equipements(database, site, groupe):
	"""
	Génère et renvoi une liste de dictionnaire
	Chaque dictionnaire contient un champ label et un champs valuequi représente un equipement
	Sera utilisé par des dropdown
	"""
	query = """SELECT DISTINCT equipement FROM equipements
	WHERE groupe='%s' AND site = '%s'""" % (groupe, site)
	data = system.db.runQuery(query)
		
	if len(data) == 0 :
		return [{"value": "Aucun","label": "Aucun"}]
	else : 
		list_options = [{"value": "Tous","label": "Tous"}]
		for elt in data : 
			list_options.append({"value": elt[0],"label":elt[0]})
		return list_options
		

def get_time(dataset, plage, field):
	"""
	Recupere un temps contenu dans un dataset contenant les 4 plages d'un équipement
	dataset columns: plage, start, end
	field: h_start, m_start, h_stop, m_stop
	"""
	return dataset.getValueAt(plage-1, field)
	


