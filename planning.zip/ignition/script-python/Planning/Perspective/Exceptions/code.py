def get_all_exception_dates(database, site, date):
	"""
	Recupère et renvoi un dataset contenant heure/minute de debut/fin	pour les 4 plages
	"""
	query = """SELECT distinct(concat(date_deb, '_&_', date_fin, '_&_', commentaire, '_&_', groupe, '_&_', equipement))
	FROM plannings_exception where site = '%s'
	and CONVERT(date_deb, DATE) > CONVERT('%s', DATE)
	order by CONVERT(date_deb, DATE) asc""" % (site, date)
	
	results = system.db.runQuery(query, database)

	headers = [
		'start_date',
		'end_date',
		'comment',
		'groupe',
		'equipement'
	]
	
	if len(results) > 0:
		data = [row[0].split('_&_') for row in results]
	else:
		#data = [[None] * len(headers)]
		data = []
		
	return system.dataset.toDataSet(headers, data)


def get_exception_dates(database, site, groupe, equipement):
	"""
	Recupère et renvoi un dataset contenant heure/minute de debut/fin	pour les 4 plages
	"""
	query = """SELECT distinct(concat(date_deb, '_&_', date_fin, '_&_', commentaire))
	FROM plannings_exception
	where site = '%s'
	and groupe = '%s'
	and equipement = '%s'
	order by CONVERT(date_deb, DATE) asc""" % (
			site,
			groupe,
			equipement,
		)
	results = system.db.runQuery(query, database)

	headers = [
		'start_date',
		'end_date',
		'comment',
	]
	
	if len(results) > 0:
		data = [row[0].split('_&_') for row in results]
	else:
		#data = [[None] * len(headers)]
		data = []
		
	return system.dataset.toDataSet(headers, data)


def get_exception_plages(database, site, groupe, equipement, date_deb, date_fin):
	"""
	Recupère et renvoi un dataset contenant heure/minute de debut/fin	pour les 4 plages
	colonnes: plage, debut, fin
	"""
	query = """SELECT
		plage,
		concat(h_start, ':', m_start) as debut,
		concat(h_stop, ':', m_stop) as fin
	FROM plannings_exception
	where site = '%s'
	and groupe = '%s'
	and equipement = '%s'
	and date_deb = '%s'
	and date_fin = '%s'
	order by plage asc""" % (
			site,
			groupe,
			equipement,
			date_deb,
			date_fin,
		)
	results = system.db.runQuery(query, database)

	headers = [
		'plage',
		'start',
		'end',
	]
	
	if len(results) > 0:
		data = [list(row) for row in results]
	else:
		#data = [[None] * len(headers)]
		data = [[i, '00:00', '00:00'] for i in range(1,5)]
		
	return system.dataset.toDataSet(headers, data)
	

def get_exception_hours(database, site, groupe, equipement, date_deb, date_fin):
	"""
	Recupère et renvoi un dataset contenant heure/minute de debut/fin	pour les 4 plages
	colonnes: plage, h_start, m_start, h_stop, m_stop
	"""
	query = """SELECT
		plage,
		h_start,
		m_start,
		h_stop,
		m_stop
	FROM plannings_exception
	where site = '%s'
	and groupe = '%s'
	and equipement = '%s'
	and date_deb = '%s'
	and date_fin = '%s'
	order by plage asc""" % (
		site,
		groupe,
		equipement,
		date_deb,
		date_fin,
	)
	results = system.db.runQuery(query, database)

	headers = [
		'plage',
		'h_start',
		'm_start',
		'h_stop',
		'm_stop',
	]
	
	if len(results) == 4:
		data = [list(row) for row in results]
	else:
		#data = [[None] * len(headers)]
		data = [[i, '00', '00', '00', '00'] for i in range(1,5)]	
		
	return system.dataset.toDataSet(headers, data)


def get_exception_plages_for_annuel(database, site, groupe, equipement, date):	
	"""
	Récupère et renvoi un dataset contenant les plages d'un équipement, la date_deb et date_fin
	d'une dérogation pour la vue annuel
	"""
	try:
		date = Planning.GetPlanning.sql_to_date(date)
		
		est_exception, date_deb, date_fin = Planning.GetPlanning.test_exception(
			database,
			site,
			groupe,
			equipement,
			date,
		)
	except:
		est_exception = False
		
	if est_exception:
		dataset = get_exception_plages(database, site, groupe, equipement, date_deb, date_fin)
		return dataset, date_deb, date_fin
	else:
		headers = [
			'plage',
			'start',
			'end',
		]
		data = [[i, '00:00', '00:00'] for i in range(1,5)]
		dataset = system.dataset.toDataSet(headers, data)
		return dataset, None, None


def test_superposition(database, site, groupe, equipement, old_date_deb, new_date_deb, old_date_fin, new_date_fin):	
	"""
	Vérifie si une période d'exception n'existe pas déjà lors de l'ajout d'une nouvelle exception
	ou lors de la modification d'une période existante
	"""
	new_date_deb = Planning.GetPlanning.sql_to_date(new_date_deb)
	new_date_fin = Planning.GetPlanning.sql_to_date(new_date_fin)
	
	if old_date_deb == -1 or old_date_fin ==-1:
		date = new_date_deb
		while system.date.isBetween(date, new_date_deb, new_date_fin):
			est_exception, date_deb, date_fin = Planning.GetPlanning.test_exception(database, site, groupe, equipement, date)
			if est_exception:
				return True
			date = system.date.addDays(date, 1)
	else:
		old_date_deb = Planning.GetPlanning.sql_to_date(old_date_deb)
		old_date_fin = Planning.GetPlanning.sql_to_date(old_date_fin)
		date = new_date_deb
		while system.date.isBefore(date, old_date_deb):
			est_exception, date_deb, date_fin = Planning.GetPlanning.test_exception(database, site, groupe, equipement, date)
			if est_exception:
				return True
			date = system.date.addDays(date, 1)
			
		date = new_date_fin
		while system.date.isAfter(date, old_date_fin):
			est_exception, date_deb, date_fin = Planning.GetPlanning.test_exception(database, site, groupe, equipement, date)
			if est_exception:
				return True
			date = system.date.addDays(date, -1)
	return False
