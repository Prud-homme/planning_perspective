def check_period(dataset):
	"""
	Verifie si la période (hebdomadaire ou dérogatoire) contient bien 4 plages
	Si ce n'est pas le cas, un dataset est initialisé à '00'
	"""
	headers = [
		'plage',
		'h_start',
		'm_start',
		'h_stop',
		'm_stop',
	]
	if len(dataset) == 4:
		data = [list(row) for row in dataset]
	else:
		data = [[i, '00', '00', '00', '00'] for i in range(1,5)]	
	return system.dataset.toDataSet(headers, data)


def hebdo_to_dataset(database, site, groupe, equipement, num_jour):
	"""
	Recupère la période hebdomadaire d'un équipement
	Retourne un dataset où chaque ligne représente une plage
	"""
	query = """SELECT
		plage,
		h_start,
		m_start,
		h_stop,
		m_stop
	FROM plannings
	where site = '%s'
	and groupe = '%s'
	and equipement = '%s'
	and jour = %d
	order by plage asc""" % (
			site,
			groupe,
			equipement,
			num_jour,
		)
	dataset = system.db.runQuery(query, database)
	return check_period(dataset)



def exception_to_dataset(database, site, groupe, equipement, date_deb, date_fin):
	"""
	Recupère la période dérogatoire d'un équipement pour une période donnée
	Retourne un dataset où chaque ligne représente une plage
	"""
	if date_deb is None or date_fin is None:
		headers = [
			'plage',
			'h_start',
			'm_start',
			'h_stop',
			'm_stop',
		]
		data = [[i, '00', '00', '00', '00'] for i in range(1,5)]	
		dataset = system.dataset.toDataSet(headers, data)
	
	else:
		query = """SELECT
			plage,
			h_start,
			m_start,
			h_stop,
			m_stop
		FROM plannings_exception
		where site = '%s'
		and groupe = '%s'
		and equipement = '%s'
		and date_deb = '%s'
		and date_fin = '%s'
		order by plage asc""" % (
			site,
			groupe,
			equipement,
			date_deb,
			date_fin,
		)
		dataset = system.db.runQuery(query, database)
	return check_period(dataset)


def get_period_dataset(
    database,
    site,
    groupe,
    equipement,
    num_jour,
    date_deb,
    date_fin,
):
    """
    Recupère une période hebdomadaire ou dérogatoire pour un équipement 
    en fonction de la valeur de num_jour
    Retourne un dataset où chaque ligne représente une page
    num_jour = 0 : exception
    num_jour 1 a 7 : hebdo
    """
    if num_jour in range(1, 8):
        dataset = hebdo_to_dataset(database, site, groupe, equipement, num_jour)

    elif num_jour == 0:
        dataset = exception_to_dataset(database, site, groupe, equipement, date_deb, date_fin)
    return dataset


def delete_row(dataset, row_index):
	"""
	Supprime une plage et décale les autres avant de rajouter une plage vide
	Reinitialise les indexs
	"""
	if row_index not in range(4):
		return dataset
		
	dataset = system.dataset.deleteRow(dataset, row_index)
	dataset = system.dataset.addRow(dataset, [4, '00', '00', '00', '00'])
	return dataset


def is_empty_plage(dataset, plage):
	"""
	Recupere une plage de temps contenu dans un dataset contenant les 4 plages d'un équipement
	Renvoi Vrai si la plage ne contient que des '00' (Faux sinon)
	field: h_start, m_start, h_stop, m_stop
	"""
	return False not in [dataset.getValueAt(plage-1, index) == "00" for index in range(1,5)]
		

def clean_dataset(dataset):
	"""
	Fait en sorte que le dataset ne dispose pas de plage vide entre des plages remplies
	etats représente une liste de booléens:
		Vrai: La plage ne contient pas que des '00'
		Faux: La plage ne contient que des '00'
	"""
	headers = list(dataset.getColumnNames())
	data = [
		[dataset.getValueAt(plage - 1, index) for index in range(5)]
		for plage in range(1, 5)
		if not is_empty_plage(dataset, plage)
	]
	
	if len(data)>0:
		zipped = zip([int(row[1] + row[2]) for row in data], data)
		sort_zip = sorted(zipped)
		sort_int, sort_data = zip(*sort_zip)
		data = list(sort_data)
	
	for i in range(len(data)-1):
		if int(data[i][3]+data[i][4]) > int(data[i+1][1]+data[i+1][2]):
			data[i+1][1] = data[i][3]
			data[i+1][2] = data[i][4]
	
	for i in range(len(data),4):
		data.append([i, '00', '00', '00', '00'])
		
	dataset = system.dataset.toDataSet(headers, data)
	for i in range(4):
		dataset = system.dataset.setValue(dataset, i, 0, i+1)
	return dataset


def hour_dropdown(value=0):
	"""
	Renvoi une liste d'options entre '00' et '23' pour un dropdown
	en ne commancant qu'à partir d'une certaine valeur (int)
	"""
	return [{'value':str(i).zfill(2),'label':str(i).zfill(2)} for i in range(24) if i >= value]
	
	
def minute_dropdown(value=0):
	"""
	Renvoi une liste d'options entre '00' et '59' pour un dropdown
	en ne commancant qu'à partir d'une certaine valeur (int)
	"""
	return [{'value':str(i).zfill(2),'label':str(i).zfill(2)} for i in range(60) if i >= value]


def get_exception_comments(database, site, groupe, equipement, date_deb, date_fin):
	"""
	Recupère et renvoi le commentaire associé à une exception
	"""
	query = """SELECT commentaire FROM plannings_exception
	where site = '%s'
	and groupe = '%s'
	and equipement = '%s'
	and date_deb = '%s'
	and date_fin = '%s'
	and plage = 1""" % (
			site,
			groupe,
			equipement,
			date_deb,
			date_fin,
		)
	results = system.db.runQuery(query, database)
	if len(results) > 0:
		return results[0][0]
	else:
		return ''
