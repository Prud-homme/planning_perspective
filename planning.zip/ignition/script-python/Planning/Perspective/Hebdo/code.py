def get_hebdo_hours(database, site, groupe, equipement, num_jour):
	"""
	Recupère et renvoi un dataset contenant heure/minute de debut/fin	pour les 4 plages
	colonnes: plage, h_start, m_start, h_stop, m_stop
	"""
	try:
		query = """SELECT
			plage,
			concat(h_start, ':', m_start) as debut,
			concat(h_stop, ':', m_stop) as fin
		FROM plannings
		where site = '%s'
		and groupe = '%s'
		and equipement = '%s'
		and jour = %d
		order by plage asc""" % (
				site,
				groupe,
				equipement,
				num_jour,
			)
		results = system.db.runQuery(query, database)
	except:
		results = []
		
	headers = [
		'plage',
		'start',
		'end',
	]

	if len(results) > 0:
		data = [list(row) for row in results]
	else:
		#data = [[None] * len(headers)]
		data = [[i, '00:00', '00:00'] for i in range(1,5)]
		
	return system.dataset.toDataSet(headers, data)
