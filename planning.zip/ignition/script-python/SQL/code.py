import system

def table_exist(database, table_schema, table_name):
	query = """SELECT column_name
FROM information_schema.columns
WHERE table_schema = '%s'
AND table_name = '%s'
ORDER BY ordinal_position ASC""".replace('\n', ' ') % (table_schema, table_name)
	results = system.db.runQuery(query, database)
	return len(results) > 0


def get_dataset(database, table_schema, table_name):
	if not table_exist(database, table_schema, table_name):
		return None

	query = "SELECT * FROM %s" % (table_name)
	results = system.db.runQuery(query, database)

	headers = list(results.getColumnNames())
	if len(results) > 0:
		data = [list(row) for row in results]
	else:
		data = [[None] * len(headers)]
	return system.dataset.toDataSet(headers, data)
	
	
def table_field_rename(database, table_schema, table_name, field):
	if not table_exist(database, table_schema, table_name) or field not in ["site", "groupe", "equipement"]:
		return None
			
	search = {
		"site": "select distinct site from equipements",
		"groupe": "select distinct site, groupe from equipements",
		"equipement": "select distinct site, groupe, equipement from equipements",
	}
	
	results = system.db.runQuery(search[field], database)
	
	headers = list(results.getColumnNames())
	headers_extract = [field]
	if len(results) > 0:
		data = [list(row) for row in results]
		data_extract = [[elt[-1]] for elt in data]
	else:
		data = [[None] * len(headers)]
		data_extract = [[None]]
		
	dataset = system.dataset.toDataSet(headers,data)
	dataset_extract = system.dataset.toDataSet(headers_extract,data_extract)
	return dataset, dataset_extract
	